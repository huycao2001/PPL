import java.util.Scanner;
public class test {
   public static void main( String args[] ) {
      Scanner myInput = new Scanner( System.in );
      int a = myInput.nextInt();
   }
}